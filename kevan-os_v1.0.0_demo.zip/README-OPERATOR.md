# kevan-os — Operator Guide

## Run
kevan-os <module> <command> [args]

## Examples
kevan-os calendar add --title "Event" --time "2026-01-17T18:00:00"
kevan-os tel call --to "+1..." --from "+1..."
kevan-os finance history
kevan-os mail inbox

## Logs
All actions emit immutable events via the hub.

## Demo Mode
To validate the system with a scripted "Day in the Life" simulation:
```powershell
# If scripts are disabled on your system, run this first:
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# Run the demo
.\run_demo.ps1
```

## Status
Production-ready. Behavior frozen under v1.0.0.
